/*
 * MinIO Cloud Storage (C) 2016 MinIO, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import JSONrpc from "../jsonrpc"

describe("jsonrpc", () => {
  it("should fail with invalid endpoint", done => {
    try {
      let jsonRPC = new JSONrpc({
        endpoint: "htt://localhost:9000",
        namespace: "Test"
      })
    } catch (e) {
      done()
    }
  })
  it("should succeed with valid endpoint", () => {
    let jsonRPC = new JSONrpc({
      endpoint: "http://localhost:9000/webrpc",
      namespace: "Test"
    })
    expect(jsonRPC.version).toEqual("2.0")
    expect(jsonRPC.host).toEqual("localhost")
    expect(jsonRPC.port).toEqual("9000")
    expect(jsonRPC.path).toEqual("/webrpc")
    expect(jsonRPC.scheme).toEqual("http")
  })
})
